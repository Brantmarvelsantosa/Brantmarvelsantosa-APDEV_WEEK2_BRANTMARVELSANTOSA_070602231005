﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TakeHome___Week_2
{
    public partial class Form2 : Form
    {
        private string wordGuess;
        private char[] guessedword;

        public Form2(string wordGuess)
        {
            InitializeComponent();
            this.wordGuess = wordGuess;
            char[] letters = wordGuess.ToCharArray(); 
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            WordGuess.Text = wordGuess;
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }
        private void WordGuess_Click(object sender, EventArgs e)
        {
           
        }
    }
}
