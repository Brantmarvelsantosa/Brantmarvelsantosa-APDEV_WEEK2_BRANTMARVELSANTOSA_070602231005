﻿namespace TakeHome___Week_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.WordLabel1 = new System.Windows.Forms.Label();
            this.WordLabel2 = new System.Windows.Forms.Label();
            this.WordLabel3 = new System.Windows.Forms.Label();
            this.WordLabel4 = new System.Windows.Forms.Label();
            this.WordLabel5 = new System.Windows.Forms.Label();
            this.TB_Word1 = new System.Windows.Forms.TextBox();
            this.TB_Word2 = new System.Windows.Forms.TextBox();
            this.TB_Word3 = new System.Windows.Forms.TextBox();
            this.TB_Word4 = new System.Windows.Forms.TextBox();
            this.TB_Word5 = new System.Windows.Forms.TextBox();
            this.ButtonPlay = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // WordLabel1
            // 
            this.WordLabel1.AutoSize = true;
            this.WordLabel1.Location = new System.Drawing.Point(33, 37);
            this.WordLabel1.Name = "WordLabel1";
            this.WordLabel1.Size = new System.Drawing.Size(64, 20);
            this.WordLabel1.TabIndex = 0;
            this.WordLabel1.Text = "Word 1:";
            // 
            // WordLabel2
            // 
            this.WordLabel2.AutoSize = true;
            this.WordLabel2.Location = new System.Drawing.Point(33, 83);
            this.WordLabel2.Name = "WordLabel2";
            this.WordLabel2.Size = new System.Drawing.Size(64, 20);
            this.WordLabel2.TabIndex = 1;
            this.WordLabel2.Text = "Word 2:";
            // 
            // WordLabel3
            // 
            this.WordLabel3.AutoSize = true;
            this.WordLabel3.Location = new System.Drawing.Point(33, 129);
            this.WordLabel3.Name = "WordLabel3";
            this.WordLabel3.Size = new System.Drawing.Size(64, 20);
            this.WordLabel3.TabIndex = 2;
            this.WordLabel3.Text = "Word 3:";
            // 
            // WordLabel4
            // 
            this.WordLabel4.AutoSize = true;
            this.WordLabel4.Location = new System.Drawing.Point(33, 177);
            this.WordLabel4.Name = "WordLabel4";
            this.WordLabel4.Size = new System.Drawing.Size(64, 20);
            this.WordLabel4.TabIndex = 3;
            this.WordLabel4.Text = "Word 4:";
            // 
            // WordLabel5
            // 
            this.WordLabel5.AutoSize = true;
            this.WordLabel5.Location = new System.Drawing.Point(33, 225);
            this.WordLabel5.Name = "WordLabel5";
            this.WordLabel5.Size = new System.Drawing.Size(64, 20);
            this.WordLabel5.TabIndex = 4;
            this.WordLabel5.Text = "Word 5:";
            // 
            // TB_Word1
            // 
            this.TB_Word1.Location = new System.Drawing.Point(104, 35);
            this.TB_Word1.Name = "TB_Word1";
            this.TB_Word1.Size = new System.Drawing.Size(236, 26);
            this.TB_Word1.TabIndex = 5;
            // 
            // TB_Word2
            // 
            this.TB_Word2.Location = new System.Drawing.Point(104, 82);
            this.TB_Word2.Name = "TB_Word2";
            this.TB_Word2.Size = new System.Drawing.Size(236, 26);
            this.TB_Word2.TabIndex = 6;
            // 
            // TB_Word3
            // 
            this.TB_Word3.Location = new System.Drawing.Point(104, 128);
            this.TB_Word3.Name = "TB_Word3";
            this.TB_Word3.Size = new System.Drawing.Size(236, 26);
            this.TB_Word3.TabIndex = 7;
            // 
            // TB_Word4
            // 
            this.TB_Word4.Location = new System.Drawing.Point(104, 175);
            this.TB_Word4.Name = "TB_Word4";
            this.TB_Word4.Size = new System.Drawing.Size(236, 26);
            this.TB_Word4.TabIndex = 8;
            // 
            // TB_Word5
            // 
            this.TB_Word5.Location = new System.Drawing.Point(104, 223);
            this.TB_Word5.Name = "TB_Word5";
            this.TB_Word5.Size = new System.Drawing.Size(236, 26);
            this.TB_Word5.TabIndex = 9;
            // 
            // ButtonPlay
            // 
            this.ButtonPlay.Location = new System.Drawing.Point(158, 278);
            this.ButtonPlay.Name = "ButtonPlay";
            this.ButtonPlay.Size = new System.Drawing.Size(108, 34);
            this.ButtonPlay.TabIndex = 10;
            this.ButtonPlay.Text = "Play!";
            this.ButtonPlay.UseVisualStyleBackColor = true;
            this.ButtonPlay.Click += new System.EventHandler(this.ButtonPlay_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1072, 569);
            this.Controls.Add(this.ButtonPlay);
            this.Controls.Add(this.TB_Word5);
            this.Controls.Add(this.TB_Word4);
            this.Controls.Add(this.TB_Word3);
            this.Controls.Add(this.TB_Word2);
            this.Controls.Add(this.TB_Word1);
            this.Controls.Add(this.WordLabel5);
            this.Controls.Add(this.WordLabel4);
            this.Controls.Add(this.WordLabel3);
            this.Controls.Add(this.WordLabel2);
            this.Controls.Add(this.WordLabel1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label WordLabel1;
        private System.Windows.Forms.Label WordLabel2;
        private System.Windows.Forms.Label WordLabel3;
        private System.Windows.Forms.Label WordLabel4;
        private System.Windows.Forms.Label WordLabel5;
        private System.Windows.Forms.TextBox TB_Word1;
        private System.Windows.Forms.TextBox TB_Word2;
        private System.Windows.Forms.TextBox TB_Word3;
        private System.Windows.Forms.TextBox TB_Word4;
        private System.Windows.Forms.TextBox TB_Word5;
        private System.Windows.Forms.Button ButtonPlay;
    }
}

