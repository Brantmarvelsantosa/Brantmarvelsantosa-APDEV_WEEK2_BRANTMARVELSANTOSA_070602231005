﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TakeHome___Week_2
{
    public partial class Form1 : Form
    {
        public string WordGuess { get; set; } 

        private void OpenForm2()
        {
            
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void ButtonPlay_Click(object sender, EventArgs e)
        {
            if (TB_Word1.TextLength > 5 || TB_Word2.TextLength > 5 || TB_Word3.TextLength > 5 || TB_Word4.TextLength > 5 || TB_Word5.TextLength > 5 || TB_Word1.TextLength < 5 || TB_Word2.TextLength < 5 || TB_Word3.TextLength < 5 || TB_Word4.TextLength < 5 || TB_Word5.TextLength < 5 || TB_Word1.Text == TB_Word2.Text || TB_Word1.Text == TB_Word3.Text || TB_Word1.Text == TB_Word4.Text || TB_Word1.Text == TB_Word5.Text || TB_Word2.Text == TB_Word1.Text || TB_Word2.Text == TB_Word3.Text || TB_Word2.Text == TB_Word4.Text || TB_Word2.Text == TB_Word5.Text || TB_Word3.Text == TB_Word1.Text || TB_Word3.Text == TB_Word2.Text || TB_Word3.Text == TB_Word4.Text || TB_Word3.Text == TB_Word5.Text || TB_Word4.Text == TB_Word1.Text || TB_Word4.Text == TB_Word2.Text || TB_Word4.Text == TB_Word3.Text || TB_Word4.Text == TB_Word5.Text || TB_Word5.Text == TB_Word1.Text || TB_Word5.Text == TB_Word2.Text || TB_Word5.Text == TB_Word3.Text || TB_Word5.Text == TB_Word4.Text)
            {
                MessageBox.Show("Error");
            }
            else
            {
                WordGuess = TB_Word1.Text;
                Form2 form2 = new Form2(WordGuess);
                form2.Show();
            }
        }
    }
}

