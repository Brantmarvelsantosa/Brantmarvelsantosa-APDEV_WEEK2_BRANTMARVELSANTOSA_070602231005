﻿namespace TakeHome___Week_2
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Button_Q = new System.Windows.Forms.Button();
            this.Button_W = new System.Windows.Forms.Button();
            this.Button_E = new System.Windows.Forms.Button();
            this.Button_R = new System.Windows.Forms.Button();
            this.Button_T = new System.Windows.Forms.Button();
            this.Button_Y = new System.Windows.Forms.Button();
            this.Button_U = new System.Windows.Forms.Button();
            this.Button_I = new System.Windows.Forms.Button();
            this.Button_O = new System.Windows.Forms.Button();
            this.Button_P = new System.Windows.Forms.Button();
            this.Button_A = new System.Windows.Forms.Button();
            this.Button_S = new System.Windows.Forms.Button();
            this.Button_D = new System.Windows.Forms.Button();
            this.Button_F = new System.Windows.Forms.Button();
            this.Button_G = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.Label_WordGuess1 = new System.Windows.Forms.Label();
            this.Label_WordGuess2 = new System.Windows.Forms.Label();
            this.Label_WordGuess3 = new System.Windows.Forms.Label();
            this.Label_WordGuess4 = new System.Windows.Forms.Label();
            this.Label_WordGuess5 = new System.Windows.Forms.Label();
            this.WordGuess = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // Button_Q
            // 
            this.Button_Q.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Q.Location = new System.Drawing.Point(94, 145);
            this.Button_Q.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Button_Q.Name = "Button_Q";
            this.Button_Q.Size = new System.Drawing.Size(78, 75);
            this.Button_Q.TabIndex = 0;
            this.Button_Q.Text = "Q";
            this.Button_Q.UseVisualStyleBackColor = true;
            this.Button_Q.Click += new System.EventHandler(this.button1_Click);
            // 
            // Button_W
            // 
            this.Button_W.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_W.Location = new System.Drawing.Point(190, 145);
            this.Button_W.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Button_W.Name = "Button_W";
            this.Button_W.Size = new System.Drawing.Size(78, 75);
            this.Button_W.TabIndex = 1;
            this.Button_W.Text = "W";
            this.Button_W.UseVisualStyleBackColor = true;
            // 
            // Button_E
            // 
            this.Button_E.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_E.Location = new System.Drawing.Point(283, 145);
            this.Button_E.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Button_E.Name = "Button_E";
            this.Button_E.Size = new System.Drawing.Size(78, 75);
            this.Button_E.TabIndex = 2;
            this.Button_E.Text = "E";
            this.Button_E.UseVisualStyleBackColor = true;
            // 
            // Button_R
            // 
            this.Button_R.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_R.Location = new System.Drawing.Point(377, 145);
            this.Button_R.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Button_R.Name = "Button_R";
            this.Button_R.Size = new System.Drawing.Size(78, 75);
            this.Button_R.TabIndex = 3;
            this.Button_R.Text = "R";
            this.Button_R.UseVisualStyleBackColor = true;
            // 
            // Button_T
            // 
            this.Button_T.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_T.Location = new System.Drawing.Point(470, 145);
            this.Button_T.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Button_T.Name = "Button_T";
            this.Button_T.Size = new System.Drawing.Size(78, 75);
            this.Button_T.TabIndex = 4;
            this.Button_T.Text = "T";
            this.Button_T.UseVisualStyleBackColor = true;
            // 
            // Button_Y
            // 
            this.Button_Y.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_Y.Location = new System.Drawing.Point(564, 145);
            this.Button_Y.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Button_Y.Name = "Button_Y";
            this.Button_Y.Size = new System.Drawing.Size(78, 75);
            this.Button_Y.TabIndex = 5;
            this.Button_Y.Text = "Y";
            this.Button_Y.UseVisualStyleBackColor = true;
            // 
            // Button_U
            // 
            this.Button_U.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_U.Location = new System.Drawing.Point(656, 145);
            this.Button_U.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Button_U.Name = "Button_U";
            this.Button_U.Size = new System.Drawing.Size(78, 75);
            this.Button_U.TabIndex = 6;
            this.Button_U.Text = "U";
            this.Button_U.UseVisualStyleBackColor = true;
            // 
            // Button_I
            // 
            this.Button_I.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_I.Location = new System.Drawing.Point(749, 145);
            this.Button_I.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Button_I.Name = "Button_I";
            this.Button_I.Size = new System.Drawing.Size(78, 75);
            this.Button_I.TabIndex = 7;
            this.Button_I.Text = "I";
            this.Button_I.UseVisualStyleBackColor = true;
            // 
            // Button_O
            // 
            this.Button_O.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_O.Location = new System.Drawing.Point(843, 145);
            this.Button_O.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Button_O.Name = "Button_O";
            this.Button_O.Size = new System.Drawing.Size(78, 75);
            this.Button_O.TabIndex = 8;
            this.Button_O.Text = "O";
            this.Button_O.UseVisualStyleBackColor = true;
            // 
            // Button_P
            // 
            this.Button_P.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_P.Location = new System.Drawing.Point(938, 145);
            this.Button_P.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Button_P.Name = "Button_P";
            this.Button_P.Size = new System.Drawing.Size(78, 75);
            this.Button_P.TabIndex = 9;
            this.Button_P.Text = "P";
            this.Button_P.UseVisualStyleBackColor = true;
            // 
            // Button_A
            // 
            this.Button_A.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_A.Location = new System.Drawing.Point(141, 243);
            this.Button_A.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Button_A.Name = "Button_A";
            this.Button_A.Size = new System.Drawing.Size(78, 75);
            this.Button_A.TabIndex = 10;
            this.Button_A.Text = "A";
            this.Button_A.UseVisualStyleBackColor = true;
            // 
            // Button_S
            // 
            this.Button_S.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_S.Location = new System.Drawing.Point(237, 243);
            this.Button_S.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Button_S.Name = "Button_S";
            this.Button_S.Size = new System.Drawing.Size(78, 75);
            this.Button_S.TabIndex = 11;
            this.Button_S.Text = "S";
            this.Button_S.UseVisualStyleBackColor = true;
            // 
            // Button_D
            // 
            this.Button_D.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_D.Location = new System.Drawing.Point(330, 243);
            this.Button_D.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Button_D.Name = "Button_D";
            this.Button_D.Size = new System.Drawing.Size(78, 75);
            this.Button_D.TabIndex = 12;
            this.Button_D.Text = "D";
            this.Button_D.UseVisualStyleBackColor = true;
            // 
            // Button_F
            // 
            this.Button_F.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_F.Location = new System.Drawing.Point(424, 243);
            this.Button_F.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Button_F.Name = "Button_F";
            this.Button_F.Size = new System.Drawing.Size(78, 75);
            this.Button_F.TabIndex = 13;
            this.Button_F.Text = "F";
            this.Button_F.UseVisualStyleBackColor = true;
            // 
            // Button_G
            // 
            this.Button_G.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Button_G.Location = new System.Drawing.Point(518, 243);
            this.Button_G.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Button_G.Name = "Button_G";
            this.Button_G.Size = new System.Drawing.Size(78, 75);
            this.Button_G.TabIndex = 14;
            this.Button_G.Text = "G";
            this.Button_G.UseVisualStyleBackColor = true;
            // 
            // button16
            // 
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button16.Location = new System.Drawing.Point(611, 243);
            this.button16.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(78, 75);
            this.button16.TabIndex = 15;
            this.button16.Text = "H";
            this.button16.UseVisualStyleBackColor = true;
            // 
            // button17
            // 
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button17.Location = new System.Drawing.Point(703, 243);
            this.button17.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(78, 75);
            this.button17.TabIndex = 16;
            this.button17.Text = "J";
            this.button17.UseVisualStyleBackColor = true;
            // 
            // button18
            // 
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button18.Location = new System.Drawing.Point(797, 243);
            this.button18.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(78, 75);
            this.button18.TabIndex = 17;
            this.button18.Text = "K";
            this.button18.UseVisualStyleBackColor = true;
            // 
            // button19
            // 
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button19.Location = new System.Drawing.Point(891, 243);
            this.button19.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(78, 75);
            this.button19.TabIndex = 18;
            this.button19.Text = "L";
            this.button19.UseVisualStyleBackColor = true;
            // 
            // button20
            // 
            this.button20.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button20.Location = new System.Drawing.Point(189, 339);
            this.button20.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(78, 75);
            this.button20.TabIndex = 19;
            this.button20.Text = "Z";
            this.button20.UseVisualStyleBackColor = true;
            // 
            // button21
            // 
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button21.Location = new System.Drawing.Point(284, 339);
            this.button21.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(78, 75);
            this.button21.TabIndex = 20;
            this.button21.Text = "X";
            this.button21.UseVisualStyleBackColor = true;
            // 
            // button22
            // 
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button22.Location = new System.Drawing.Point(377, 339);
            this.button22.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(78, 75);
            this.button22.TabIndex = 21;
            this.button22.Text = "C";
            this.button22.UseVisualStyleBackColor = true;
            // 
            // button23
            // 
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button23.Location = new System.Drawing.Point(472, 339);
            this.button23.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(78, 75);
            this.button23.TabIndex = 22;
            this.button23.Text = "V";
            this.button23.UseVisualStyleBackColor = true;
            // 
            // button24
            // 
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button24.Location = new System.Drawing.Point(566, 339);
            this.button24.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(78, 75);
            this.button24.TabIndex = 23;
            this.button24.Text = "B";
            this.button24.UseVisualStyleBackColor = true;
            // 
            // button25
            // 
            this.button25.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button25.Location = new System.Drawing.Point(657, 339);
            this.button25.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(78, 75);
            this.button25.TabIndex = 24;
            this.button25.Text = "N";
            this.button25.UseVisualStyleBackColor = true;
            // 
            // button26
            // 
            this.button26.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button26.Location = new System.Drawing.Point(750, 339);
            this.button26.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(78, 75);
            this.button26.TabIndex = 25;
            this.button26.Text = "M";
            this.button26.UseVisualStyleBackColor = true;
            // 
            // Label_WordGuess1
            // 
            this.Label_WordGuess1.AutoSize = true;
            this.Label_WordGuess1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_WordGuess1.Location = new System.Drawing.Point(434, 70);
            this.Label_WordGuess1.Name = "Label_WordGuess1";
            this.Label_WordGuess1.Size = new System.Drawing.Size(36, 37);
            this.Label_WordGuess1.TabIndex = 26;
            this.Label_WordGuess1.Text = "_";
            // 
            // Label_WordGuess2
            // 
            this.Label_WordGuess2.AutoSize = true;
            this.Label_WordGuess2.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_WordGuess2.Location = new System.Drawing.Point(476, 70);
            this.Label_WordGuess2.Name = "Label_WordGuess2";
            this.Label_WordGuess2.Size = new System.Drawing.Size(36, 37);
            this.Label_WordGuess2.TabIndex = 27;
            this.Label_WordGuess2.Text = "_";
            // 
            // Label_WordGuess3
            // 
            this.Label_WordGuess3.AutoSize = true;
            this.Label_WordGuess3.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_WordGuess3.Location = new System.Drawing.Point(518, 70);
            this.Label_WordGuess3.Name = "Label_WordGuess3";
            this.Label_WordGuess3.Size = new System.Drawing.Size(36, 37);
            this.Label_WordGuess3.TabIndex = 28;
            this.Label_WordGuess3.Text = "_";
            // 
            // Label_WordGuess4
            // 
            this.Label_WordGuess4.AutoSize = true;
            this.Label_WordGuess4.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_WordGuess4.Location = new System.Drawing.Point(560, 70);
            this.Label_WordGuess4.Name = "Label_WordGuess4";
            this.Label_WordGuess4.Size = new System.Drawing.Size(36, 37);
            this.Label_WordGuess4.TabIndex = 29;
            this.Label_WordGuess4.Text = "_";
            // 
            // Label_WordGuess5
            // 
            this.Label_WordGuess5.AutoSize = true;
            this.Label_WordGuess5.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Label_WordGuess5.Location = new System.Drawing.Point(602, 70);
            this.Label_WordGuess5.Name = "Label_WordGuess5";
            this.Label_WordGuess5.Size = new System.Drawing.Size(36, 37);
            this.Label_WordGuess5.TabIndex = 30;
            this.Label_WordGuess5.Text = "_";
            // 
            // WordGuess
            // 
            this.WordGuess.AutoSize = true;
            this.WordGuess.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WordGuess.Location = new System.Drawing.Point(918, 86);
            this.WordGuess.Name = "WordGuess";
            this.WordGuess.Size = new System.Drawing.Size(30, 32);
            this.WordGuess.TabIndex = 31;
            this.WordGuess.Text = "_";
            this.WordGuess.Click += new System.EventHandler(this.WordGuess_Click);
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1110, 586);
            this.Controls.Add(this.WordGuess);
            this.Controls.Add(this.Label_WordGuess5);
            this.Controls.Add(this.Label_WordGuess4);
            this.Controls.Add(this.Label_WordGuess3);
            this.Controls.Add(this.Label_WordGuess2);
            this.Controls.Add(this.Label_WordGuess1);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.Button_G);
            this.Controls.Add(this.Button_F);
            this.Controls.Add(this.Button_D);
            this.Controls.Add(this.Button_S);
            this.Controls.Add(this.Button_A);
            this.Controls.Add(this.Button_P);
            this.Controls.Add(this.Button_O);
            this.Controls.Add(this.Button_I);
            this.Controls.Add(this.Button_U);
            this.Controls.Add(this.Button_Y);
            this.Controls.Add(this.Button_T);
            this.Controls.Add(this.Button_R);
            this.Controls.Add(this.Button_E);
            this.Controls.Add(this.Button_W);
            this.Controls.Add(this.Button_Q);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form2";
            this.Text = "Form2";
            this.Load += new System.EventHandler(this.Form2_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button Button_Q;
        private System.Windows.Forms.Button Button_W;
        private System.Windows.Forms.Button Button_E;
        private System.Windows.Forms.Button Button_R;
        private System.Windows.Forms.Button Button_T;
        private System.Windows.Forms.Button Button_Y;
        private System.Windows.Forms.Button Button_U;
        private System.Windows.Forms.Button Button_I;
        private System.Windows.Forms.Button Button_O;
        private System.Windows.Forms.Button Button_P;
        private System.Windows.Forms.Button Button_A;
        private System.Windows.Forms.Button Button_S;
        private System.Windows.Forms.Button Button_D;
        private System.Windows.Forms.Button Button_F;
        private System.Windows.Forms.Button Button_G;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Label Label_WordGuess1;
        private System.Windows.Forms.Label Label_WordGuess2;
        private System.Windows.Forms.Label Label_WordGuess3;
        private System.Windows.Forms.Label Label_WordGuess4;
        private System.Windows.Forms.Label Label_WordGuess5;
        private System.Windows.Forms.Label WordGuess;
    }
}